# Tạo tên tiếng việt | id ngẫu nhiên 
Dữ liêu các trường tên và tên đệm chưa được chuẩn xác lắm cũng như chưa đầy đủ.

Thử nghiệm: https://doanminhquang.github.io/ViNameGenerator <br>
Dự phòng: https://vinamegenerator.pages.dev
